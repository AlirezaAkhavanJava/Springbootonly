create view active_young_customers(id, email, name, age, status, created_at, address, country, bag) as
SELECT id,
       email,
       name,
       age,
       status,
       created_at,
       address,
       country,
       bag
FROM customers
WHERE status::text = 'active'::text
  AND age < 60;

alter table active_young_customers
    owner to postgres;

